// Question.jsx
import React from "react";
function Question() {
  return <div className="card">Здесь будasdfasет расчёт финкода ✨</div>;
}
export default Question
