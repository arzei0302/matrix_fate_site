import * as React from 'react';
import { useState, useEffect } from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import LockIcon from '@mui/icons-material/Lock';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { useTranslation } from 'react-i18next';
import './Accordions.scss';

const Accordions = ({ data, programs }) => {
  const [expanded, setExpanded] = useState(null);
  const [expandedPrograms, setExpandedPrograms] = useState([]);
  const [accordionData, setAccordionData] = useState([]);
  const { t } = useTranslation();
  const accessToken = localStorage.getItem("accessToken");

  useEffect(() => {
    if (!data || typeof data !== 'object') return;

    const transformedData = Object.entries(data).map(([key, value]) => {
      const val = Array.isArray(value) && value.length > 0 ? value[0] : value;
      const realCategory = val?.category?.category || val?.category || {};
      const description = val?.description || realCategory?.description || '';

      return {
        key,
        title: realCategory?.title || val?.title || key,
        description,
        category: realCategory
      };
    });

    setAccordionData(transformedData);
  }, [data]);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : null);
  };

  const toggleProgram = (key) => {
    setExpandedPrograms((prev) =>
        prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  const renderTalent = (talent) => {
    if (!talent) return null;

    return (
        <div className="talent-block" key={talent.title}>
          <Typography variant="subtitle1">{t(talent.title)}</Typography>
          {talent.description?.includes('<') ? (
              <Typography
                  variant="body2"
                  dangerouslySetInnerHTML={{ __html: t(talent.description) }}
              />
          ) : (
              <Typography variant="body2">{t(talent.description)}</Typography>
          )}
        </div>
    );
  };

  const renderNestedTalents = (content) => {
    const talents = [];

    if (typeof content.category === 'object') {
      for (const value of Object.values(content.category)) {
        if (typeof value === 'object' && (value.title || value.description)) {
          talents.push(renderTalent(value));
        }
      }
    }

    return talents;
  };

  return (
      <div className="accordion-container">
        {accordionData.map((content, index) => (
            <Accordion
                key={index}
                expanded={expanded === `panel-${index}`}
                onChange={handleChange(`panel-${index}`)}
            >
              <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                <div className="accordion-summary-content">
                  <Typography component="span" className="accordion-title">
                    {t(content.title)}
                  </Typography>
                  {!content.description && (
                      <div className="unlock-wrapper">
                        <LockIcon fontSize="small" className="lock-icon" />
                      </div>
                  )}
                </div>
              </AccordionSummary>

              <AccordionDetails>
                <Typography
                    variant="body1"
                    dangerouslySetInnerHTML={{
                      __html: content?.description || '<p>No description</p>',
                    }}
                />
                {renderNestedTalents(content)}
              </AccordionDetails>
            </Accordion>
        ))}

        {programs && programs.length > 0 && (
            <Accordion expanded={expanded === 'programs'} onChange={handleChange('programs')}>
              <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                <Typography component="span" className="accordion-title">
                  {t("programs")}
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <div className="program-list">
                  {programs.map((program, idx) => {
                    const key = `program-inner-${idx}`;
                    const isInnerExpanded = expandedPrograms.includes(key);
                    const isPaid = program?.is_paid === true;

                    return (
                        <div className="program-item" key={key}>
                          <div
                              className="program-header"
                              onClick={() => {
                                if (!isPaid) toggleProgram(key);
                              }}
                              style={{ cursor: !isPaid ? 'pointer' : 'default' }}
                          >
                            {isPaid ? (
                                <LockIcon fontSize="small" />
                            ) : isInnerExpanded ? (
                                <KeyboardArrowDownIcon fontSize="small" />
                            ) : (
                                <KeyboardArrowUpIcon fontSize="small" />
                            )}

                            <Typography variant="body2">
                              {isPaid
                                  ? t(program.name)
                                  : `${program.marker_1_value}-${program.marker_2_value}-${program.marker_3_value} ${t(program.name)}`}
                            </Typography>
                          </div>

                          {!isPaid && isInnerExpanded && (
                              <div className="program-description">
                                <Typography
                                    variant="body2"
                                    dangerouslySetInnerHTML={{
                                      __html: t(program.description || 'noDescription'),
                                    }}
                                />
                              </div>
                          )}
                        </div>
                    );
                  })}
                </div>
              </AccordionDetails>
            </Accordion>
        )}
      </div>
  );
};

export default Accordions;